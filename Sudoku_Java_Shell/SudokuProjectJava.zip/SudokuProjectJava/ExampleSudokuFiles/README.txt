These puzzles were taken from project euler problem 96
http://projecteuler.net/problem=96

